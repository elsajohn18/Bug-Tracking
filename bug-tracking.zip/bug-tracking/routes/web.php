<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', 'Auth\AuthController@register')->name('register');
Route::post('/register', 'Auth\AuthController@storeUser');

Route::get('/login', 'Auth\AuthController@login')->name('login');
Route::post('/login', 'Auth\AuthController@authenticate');
Route::get('logout', 'Auth\AuthController@logout')->name('logout');

Route::get('/home', 'Auth\AuthController@home')->name('home');

Route::get('/dummyuser', 'Auth\AuthController@dummyuser')->name('dummyuser');

Route::resource('/project', 'ProjectController');
Route::resource('/issue', 'IssueController');
Route::get('/issue','IssueController@index');
Route::post('/issue','IssueController@index');
Route::get('/project','ProjectController@index');
Route::post('/project','ProjectController@index');
Route::post('/project/create','ProjectController@store')->name('project.store');
Route::post('/issue/create','IssueController@store')->name('issue.store');
Route::any('/viewissues/{id}', 'ProjectController@viewissues');
Route::get('/singleissue/{id}', 'ProjectController@singleissue');
 Route::get('/issue/show/{id}', 'IssueController@show');
Route::get('/changeStatus/{id}', 'IssueController@changeStatus');
Route::get('/ChangeStatusProject/{id}', 'IssueController@ChangeStatusProject');
