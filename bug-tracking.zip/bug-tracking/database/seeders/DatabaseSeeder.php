<?php
namespace Database\Seeders;

use Illuminate\Database\Seeders;
use Illuminate\Database\Eloquent\Model;
namespace Database\Seeders;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
		$this->call(UserTableSeeder::class);
	}
}