


<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12" style="display: flex;">
         <div class="col-md-6">
           <a href="<?php echo e(route('project.create')); ?>" class="button">Create Project</a></div>
         <div class="col-md-6">
          <form action="" method="POST">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<input type="text" name="name" value="<?php echo e($keyword); ?>" placeholder="Name/Description">
<button type="submit" class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success ">Search </button>
</form>
</div>
      </div>

      <div class="col-md-8">
        <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('viewissues',$data->id)); ?>">
         <div class="card">
            <div class="card-body"> 
               <div class="repeat">
                  <div class="outer">
                     <div class="div1"><?php echo e($data->name); ?></div>
                     <div class="div2">No.of open issues:  <?php echo e($data->OpenCount); ?></div>
                     <div class="div3">Status : <?php echo e($data->status); ?></div>
                  </div>
                  <div class="div4"><?php echo e($data->description); ?></div>
               </div> 
            </div>
         </div>
       </a>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<style type="text/css">
  a{
    color: #000 !important;
    text-decoration: none !important;
  }
   .outer{
   display: flex;
   width: 100%;
   }
   .div1,.div2,.div3{
   width: 33.33%;
   }
   .div4{
   width: 100%;
   }
   .card{
    margin-bottom: 2rem;
   }
   .div1{
    font-weight: bold;
   }
   .button {
    display: block;
    width: 115px;
    height: 45px;
    background: #b8b4a2;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    line-height: 25px;
    margin: 0 1rem;
}
</style>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elsa\laravelcustomauth\resources\views/project.blade.php ENDPATH**/ ?>