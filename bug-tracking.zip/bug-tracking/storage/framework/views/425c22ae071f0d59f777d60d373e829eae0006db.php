<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Bug Tracking</title>
    <!-- Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <?php if(Auth::user()): ?>
              <a href="<?php echo e(url('project')); ?>" class="button">Project</a>
                <a href="<?php echo e(url('home')); ?>" class="button">Home</a>
                <?php endif; ?>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                      <?php if(Auth::user()): ?>
                            <li class="nav-item dropdown">
                                <a >
                                    <?php echo e(Auth::user()->name); ?> 
                                </a><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" style="background-color: grey">
                                        Logout
                                    </a>
                                
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<style type="text/css">
    

.button {
    display: block;
    width: 115px;
    height: 45px;
    background: #296EDB;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    line-height: 25px;
    margin: 0 1rem;
}
</style><?php /**PATH D:\xampp\htdocs\elsa\laravelcustomauth\resources\views/layouts/app.blade.php ENDPATH**/ ?>