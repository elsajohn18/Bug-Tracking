

<?php $__env->startSection('content'); ?>
 <?php 
  if($issue_details!=""){ 

    $tracker=$issue_details->tracker;
    $id=$issue_details->id ;
    $description=$issue_details->description ;
 	$duty = 'Edit' ;
 	$heading = 'Edit' ;
	$small= 'The place where you can edit issue.';
               }
                else
               {
                 $id='';
                 $tracker=''; 
                 $description=''; 
                 $duty = 'Save' ;
                 $heading = 'Add' ;
                 $small= 'The place where you can add new issue.';
                }
                
?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    
<strong><?php echo e($message); ?></strong>
</div>

<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<strong><?php echo e($error); ?></strong>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<?php endif; ?>
<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">Create/Edit Issue  </div>

<div class="card-body">
<?php if($issue_details!=""): ?> 
<form method="post" action="<?php echo e(route('issue.update', $id)); ?>">
  <input type="hidden" name="projectid" value="<?php echo e($issue_details->projectid); ?>">
  <?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>  
<?php else: ?>
<?php  $proid =  $projectid->id?>
<form method="POST" action="<?php echo e(route('issue.store')); ?>">
<input type="hidden" name="projectid" value="<?php echo e($proid); ?>">
<?php echo csrf_field(); ?>
<?php endif; ?>

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Name</label>

<div class="col-md-6">
 <select name ="tracker" id="tracker"  class="form-control" >
<option  selected="selected" value=""> Select Tracker </option>
<option  <?php if(old('tracker',$tracker)=='Feature') { ?> selected <?php  } ?> value="Feature">Feature</option >
<option  <?php if(old('tracker',$tracker)=='Bug') { ?> selected <?php  } ?> value="Bug">Bug</option >
</select>
</div>
</div>

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Description</label>

<div class="col-md-6">
 <textarea name="description" ><?php echo e($description); ?></textarea>
</div>
</div>
<div class="form-group row mb-0">
<div class="col-md-6 offset-md-4">
<button type="submit" class="btn btn-primary">
<?php echo e(__('Register')); ?>

</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elsa\laravelcustomauth\resources\views/add_issue.blade.php ENDPATH**/ ?>