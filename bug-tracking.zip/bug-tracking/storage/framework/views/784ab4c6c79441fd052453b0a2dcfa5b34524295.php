

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="col-md-12"><a href="<?php echo e(route('project.create')); ?>">Create Project</a></div>
            <div class="col-md-12"></div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Project</div>

                <div class="card-body">
                    <table style="width:100%">
  <thead>
  <tr>
    <th>Projectname</th>
    <th>No.of issues</th> 
    <th>Staus</th>
  </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $issue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="gap">
        <a  style="color:white;text-decoration: none;" href="<?php echo e(route('issues.edit',$data->project_id)); ?>">
  <tr>
    <td><?php echo e($data->name); ?></td>
    <td>1</td>
    <td><?php echo e($data->status); ?></td>
  </tr>
   <tr>
    <td colspan="4"><?php echo e($data->description); ?></td>
  </tr>
  </a>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elsa\laravelcustomauth\resources\views/issue.blade.php ENDPATH**/ ?>