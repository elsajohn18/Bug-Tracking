

<?php $__env->startSection('content'); ?>
 <?php 
  if($project_details!=""){ 

    $name=$project_details->name;
    $id=$project_details->id ;
    $description=$project_details->description ;
   $duty = 'Edit' ;
             }
           else
             {
             	$name=''; 
                 $id='';
                 $description=''; 
                 $duty = 'Create' ;
               }
                
?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    
<strong><?php echo e($message); ?></strong>
</div>

<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<strong><?php echo e($error); ?></strong>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<?php endif; ?>
<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">Create Project</div>

<div class="card-body">
<?php if($project_details!=""): ?> 
<form method="post" action="<?php echo e(route('project.update', $id)); ?>">
<?php echo method_field('PATCH'); ?>  
<?php else: ?>
<form method="POST" action="<?php echo e(route('project.store')); ?>">
<?php echo csrf_field(); ?>
<?php endif; ?>
<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Name</label>

<div class="col-md-6">
 <input name="name" placeholder="Project Name" type="text" class="form-control" value="<?php echo e($name); ?>" required="">
</div>
</div>

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Description</label>

<div class="col-md-6">
 <textarea name="description"><?php echo e($description); ?></textarea>
</div>
</div>
<div class="form-group row mb-0">
<div class="col-md-6 offset-md-4">
<button type="submit" class="btn btn-primary">
Create Project
</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elsa\laravelcustomauth\resources\views/add_project.blade.php ENDPATH**/ ?>