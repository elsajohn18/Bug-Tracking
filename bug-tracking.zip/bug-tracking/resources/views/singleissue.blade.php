@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="col-md-12" style="display: flex;"><td style="text-align:center; ">
<form action="{{ url('changeStatus/'.$data->id)}}" method="get" onSubmit="return confirm('Do you want to Close issue ?') ">
@csrf
<?php if($data->status=='NEW'){?>
<button class="status-new">Close Issue</button>
<?php }else{?>
<button class="status-close">Closed</button>
<?php }?>
</form>
</td></a>
          
            <div class="col-md-12"></div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Issue #{{$data->id}}</div>

                <div class="card-body">
                    <div class="tracker">Tracker : {{$data->tracker}}</div>
                   <div>Description <br> {{$data->description}}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
<style type="text/css">
    .tracker{
        margin-bottom: 1rem;
    }
    .status-new{
  background-color: #f0cccd;
  border: none;
  color: #000;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 0px 2px;
  cursor: pointer;
}
.status-close{
  background-color: green;
  border: none;
  color: #000;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 0px 2px;
  cursor: pointer;
}
.button2{
      display: block;
    width: 115px;
    height: 45px;
    background: #296EDB;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    line-height: 25px;
    margin: 0 1rem;
    font-size: 11px;
}
}
</style>