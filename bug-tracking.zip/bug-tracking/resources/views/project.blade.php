

@extends('layouts.app')
@section('content')
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12" style="display: flex;">
         <div class="col-md-6">
           <a href="{{ route('project.create')}}" class="button">Create Project</a></div>
         <div class="col-md-6">
          <form action="" method="POST">
<input type="hidden" name="_token" value="{{ csrf_token() }}">
<input type="text" name="name" value="{{$keyword}}" placeholder="Name/Description">
<button type="submit" class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success ">Search </button>
</form>
</div>
      </div>

      <div class="col-md-8">
        @foreach ($project as $data)
        <a href="{{ url('viewissues',$data->id)}}">
         <div class="card">
            <div class="card-body"> 
               <div class="repeat">
                  <div class="outer">
                     <div class="div1">{{$data->name}}</div>
                     <div class="div2">No.of open issues:  {{$data->OpenCount}}</div>
                     <div class="div3">Status : {{$data->status}}</div>
                  </div>
                  <div class="div4">{{$data->description}}</div>
               </div> 
            </div>
         </div>
       </a>
         @endforeach
      </div>
   </div>
</div>
@endsection
<style type="text/css">
  a{
    color: #000 !important;
    text-decoration: none !important;
  }
   .outer{
   display: flex;
   width: 100%;
   }
   .div1,.div2,.div3{
   width: 33.33%;
   }
   .div4{
   width: 100%;
   }
   .card{
    margin-bottom: 2rem;
   }
   .div1{
    font-weight: bold;
   }
   .button {
    display: block;
    width: 115px;
    height: 45px;
    background: #b8b4a2;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    line-height: 25px;
    margin: 0 1rem;
}
</style>

