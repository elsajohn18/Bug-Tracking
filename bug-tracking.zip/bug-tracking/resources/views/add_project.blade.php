@extends('layouts.app')

@section('content')
 <?php 
  if($project_details!=""){ 

    $name=$project_details->name;
    $id=$project_details->id ;
    $description=$project_details->description ;
   $duty = 'Edit' ;
             }
           else
             {
             	$name=''; 
                 $id='';
                 $description=''; 
                 $duty = 'Create' ;
               }
                
?>
@if ($message = Session::get('success'))
<div class="alert alert-success alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    
<strong>{{ $message }}</strong>
</div>

@endif
@if ($errors->any())
<div class="alert alert-danger alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    

@foreach ($errors->all() as $error)

<strong>{{ $error }}</strong>

@endforeach

</div>



@endif
<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">Create Project</div>

<div class="card-body">
@if($project_details!="") 
<form method="post" action="{{ route('project.update', $id) }}">
@method('PATCH')  
@else
<form method="POST" action="{{ route('project.store') }}">
@csrf
@endif
<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Name</label>

<div class="col-md-6">
 <input name="name" placeholder="Project Name" type="text" class="form-control" value="{{$name}}" required="">
</div>
</div>

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Description</label>

<div class="col-md-6">
 <textarea name="description">{{$description }}</textarea>
</div>
</div>
<div class="form-group row mb-0">
<div class="col-md-6 offset-md-4">
<button type="submit" class="btn btn-primary">
Create Project
</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
@endsection