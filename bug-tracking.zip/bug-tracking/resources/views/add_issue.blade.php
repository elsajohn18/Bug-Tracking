@extends('layouts.app')

@section('content')
 <?php 
  if($issue_details!=""){ 

    $tracker=$issue_details->tracker;
    $id=$issue_details->id ;
    $description=$issue_details->description ;
 	$duty = 'Edit' ;
 	$heading = 'Edit' ;
	$small= 'The place where you can edit issue.';
               }
                else
               {
                 $id='';
                 $tracker=''; 
                 $description=''; 
                 $duty = 'Save' ;
                 $heading = 'Add' ;
                 $small= 'The place where you can add new issue.';
                }
                
?>
@if ($message = Session::get('success'))
<div class="alert alert-success alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    
<strong>{{ $message }}</strong>
</div>

@endif
@if ($errors->any())
<div class="alert alert-danger alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    

@foreach ($errors->all() as $error)

<strong>{{ $error }}</strong>

@endforeach

</div>



@endif
<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">Create/Edit Issue  </div>

<div class="card-body">
@if($issue_details!="") 
<form method="post" action="{{ route('issue.update', $id) }}">
  <input type="hidden" name="projectid" value="{{$issue_details->projectid}}">
  @csrf
@method('PATCH')  
@else
<?php  $proid =  $projectid->id?>
<form method="POST" action="{{ route('issue.store') }}">
<input type="hidden" name="projectid" value="{{$proid}}">
@csrf
@endif

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Name</label>

<div class="col-md-6">
 <select name ="tracker" id="tracker"  class="form-control" >
<option  selected="selected" value=""> Select Tracker </option>
<option  <?php if(old('tracker',$tracker)=='Feature') { ?> selected <?php  } ?> value="Feature">Feature</option >
<option  <?php if(old('tracker',$tracker)=='Bug') { ?> selected <?php  } ?> value="Bug">Bug</option >
</select>
</div>
</div>

<div class="form-group row">
<label for="name" class="col-md-4 col-form-label text-md-right">Description</label>

<div class="col-md-6">
 <textarea name="description" >{{$description }}</textarea>
</div>
</div>
<div class="form-group row mb-0">
<div class="col-md-6 offset-md-4">
<button type="submit" class="btn btn-primary">
{{ __('Register') }}
</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
@endsection