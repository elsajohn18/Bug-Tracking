

@extends('layouts.app')
@section('content')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12">
         <div class="col-md-12" style="display: flex;">
          <?php if(!empty($dataproject)){?>
           <a href="#"><td style="text-align:center; ">
<form action="{{ url('ChangeStatusProject/'.$dataproject->pid)}}" method="get" onSubmit="return confirm('Do you want to Close Project ?') ">
@csrf
<button class="status-new">Close Project</button>
</form>
</td></a>
<?php }?>
           <?php if(!empty($dataproject)){?>
           <a href="{{ route('issue.show',$dataproject->pid)}}" class="button"><i class="fa fa-plus" aria-hidden="true"></i>Create Issue</a>
        <?php }?>

         </div>
@if ($message = Session::get('success'))
<div class="alert alert-success alert-block">

<button type="button" class="close" data-dismiss="alert">×</button>    
<strong>{{ $message }}</strong>
</div>

@endif
         <div class="col-md-8">
            <div class="card" style="border:none !important;">
            <div class="card-body"> 
                    <?php if(!empty($dataproject)){?>
                    <h2>{{$dataproject->pname}}</h2>
                    <p>{{$dataproject->pdesc}}</p>
                  <?php } ?>
                </div>
            </div>
 
         </div>
      </div>
      <div class="col-md-12" style="width: 100%">
                     <form action="" method="POST" style="display: flex;">
<input type="hidden" name="_token" value="{{ csrf_token() }}">
<div class="col-md-3">
  <span>Name/Description</span>
<input type="text" name="name"  class="form-control" value="{{$keyword}}" placeholder="Name/Description">
</div>
<div class="col-md-3">
  <span>Tracker</span>
<select name="tracker" class="form-control">
  <option value="All" <?php if($tracker=='All') echo "selected" ?>>All</option>
<option value="Feature" <?php if($tracker=='Feature') echo "selected" ?>>Feature</option>
<option value="Bug" <?php if($tracker=='Bug') echo "selected" ?>>Bug</option>
</select>
</div>
<div class="col-md-3">
  <span>Status</span>
<select name="status" class="form-control">
  <option value="All" <?php if($status=='All') echo "selected" ?>>All</option>
<option value="NEW" <?php if($status=='NEW') echo "selected" ?>>New</option>
<option value="CLOSED" <?php if($status=='CLOSED') echo "selected" ?>>Closed</option>
</select>
</div>
<div class="col-md-3">

<button type="submit" class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success " style="margin-top: 24px;">Search</button>
</div>
</form>
      </div>
      <div class="col-md-8">
        <p>Issues</p>
        @foreach($data as $issue)
         <div class="card">
            <div class="card-body"> 
               <div class="repeat">
                  <div class="outer">
                     <div class="div1">{{$issue->id}}</div>
                     <div class="div2">{{$issue->tracker}}</div>
                     <div class="div3">{{$issue->status}}</div>
                  
                  <div class="div4">{{$issue->description}}</div>
                   <div class="div5">{{$issue->created_at}}</div>
                    <div class="div6">  <a  style="color:white;text-decoration: none;" href="{{ url('singleissue',$issue->id)}}"><button class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success n0-btn" >View</button></a></div>
                    <div class="div7"><a  style="color:white;text-decoration: none;" href="{{ route('issue.edit',$issue->id)}}"><button class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success n1-btn">Edit</button></a></div>
                    <div class="div8"><td style="text-align:center; ">
<form action="{{ url('changeStatus/'.$issue->id)}}" method="get" onSubmit="return confirm('Do you want to Close issue ?') ">
@csrf
<?php if($issue->status=='NEW'){?>
<button class="status-new">Close</button>
<?php }else{?>
<button class="status-close">Closed</button>
<?php }?>
</form>
</td></div>
                    </div>
               </div> 
            </div>
         </div>
         @endforeach
      </div>
   </div>
</div>
@endsection
<style type="text/css">
  .n0-btn{
    background-color: #b5b533 !important;
    border:none !important;
  }
   .n1-btn{
    background-color: #299c9c !important;
    border:none !important;
  }
   .outer{
   display: flex;
   width: 100%;
   }
   .div1,.div2,.div3,.div4,.div5,.div6,.div7,.div8{
   width: 15%;
   }
   .card{
    margin-bottom: 2rem;
   }
   .button {
    display: block;
    width: 115px;
    height: 45px;
    background: #b8b4a2;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    line-height: 25px;
    margin: 0 1rem;
}
   .button1 {
    display: block;
    width: 115px;
    height: 45px;
    background: #f0cccd;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    line-height: 25px;
    margin: 0 1rem;
}
.card:nth-child(odd) {
    border: 1px solid red !important;
}
.card {
    border: 1px solid blue !important;
}
.status-new{
  background-color: #f0cccd;
  border: none;
  color: #000;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 0px 2px;
  cursor: pointer;
}
.status-close{
  background-color: #fff;
  border: none;
  color: green;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 0px 2px;
  cursor: pointer;
}
</style>

