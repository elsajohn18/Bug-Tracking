<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Issue extends Model
{
       protected $table = 'issue';
       protected $primaryKey = 'id';
	   protected $fillable = ['tracker','projectid','description','status'];
}
