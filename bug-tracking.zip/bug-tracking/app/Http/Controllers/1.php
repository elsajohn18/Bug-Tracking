//dd($keyword);
    // $project = Project::selectRaw('project.*, sum(issue.status) as openissue')
    //         ->join('issue', 'issue.projectid', '=', 'project.id')
    //         ->where('issue.status','NEW')
    //         ->groupBy('issue.projectid')
    //         ->get();
           

              // $total = \App\Project::orderby('id','DESC')->get();
              // foreach ($total as $value) {
              // 	$issue = \App\Issue::where('issue.id',$value->id)->orderby('id','DESC')->get();
              // }
              // dd($issue);
            // ->groupBy('projectid')->get();
            //dd($total);

    // $project =\App\Project::leftjoin('project', 'project.id', '=','issue.projectid')->get();
    // dd($project);
    // foreach ($project as $value) {
    // 	$total = Issue::
    //          ->select(DB::raw('count(*) as total'))
    //          ->where('issue.status','NEW')
    //          ->where('project.id',$value->projectid)
    //          ->get();
    //          dd($total);
    // }
    $total_board = DB::table('project')->get();
           // ->leftjoin('issue','issue.projectid','=','project.id')
           //  ->select(DB::raw('sum(issue.status) as user_count'))
           //  ->where('issue.status','OPEN')
           //  ->groupby('issue.projectid')->get();
            // ->select(DB::raw('sum(project.status)as points'))
            // ->orderBy('project.id','DESC')->get();
           
            foreach ($total_board as $value) {
            	$issue = DB::table('issue')->leftjoin('project','project.id','=','issue.projectid')->where('issue.projectid',$value->id)->get();
            	$resultdata[] = $issue;
            	
            	dd($resultdata);
            }