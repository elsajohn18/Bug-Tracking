<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Session;
use App\Issue;
use App\Project;
use Hash;

class IssueController extends Controller
{
	public function index(){
    $issue =\App\Issue::orderBy('id','DESC')->get();
    return view('issue',['page'=>'issue','issue'=>$issue] );
		}

    public function create()
    {
        $issue_details = '';
        
        return view('add_issue',['issue_details'=>$issue_details]);
    }
public function store(Request $request)
    {

        $validator = Validator::make($request->all(),[
            'tracker' => 'required',
            'description' => 'required',
        ]);
           if ($validator->fails()) {
            return redirect('/issue')
                        ->withErrors($validator)
                        ->withInput();
        }
        else
        {   

        	$storeData=$request->all();
        	$storeData['status'] = 'NEW';
            $storeData['projectid'] = $request->projectid;
        	$Issue = Issue::create($storeData);
        }

        return back()->with('success', 'Issue added successfully.');
    }
         public function show($id)
    {
        $issue_details = '';
        $projectid = Project::find($id);
        // dd($projectid);
        return view('add_issue',['issue_details'=>$issue_details,'projectid'=>$projectid]);
    }
    public function edit($id)
    {
        
        $issue_details = Issue::find($id);
        //$projectid = Issue::find($id['projectid']);
        //dd($issue_details);
        return view('add_issue',compact('page','issue_details'));
    }
   
    public function update(Request $request,$id){
    $validator = Validator::make($request->all(), [
    'tracker' => 'required',
    'description'=>'required',


]);

if ($validator->fails()) {

return redirect('issue/'.$id.'/edit')
->withErrors($validator)
->withInput();
}
else
{
    $updateData=$request->all();
    $issue = Issue::find($id)->update($updateData);
}return back()->with('success','Updated Successfully!');
         }

 public function changeStatus($id){

$issue = Issue::where('id',$id)->first();

if($issue->status=='NEW')
{  
$issue->status='CLOSED';
}
else
{   
$issue->status='NEW';
}
$issue->save();
return back()->with('success', 'Status Changed.');
}  
public function ChangeStatusProject($id){
    $project=Project::join('issue','issue.projectid','=','project.id')->where('project.id', $id)->where('issue.status',"CLOSED")->update(['project.status' => 'closed']);
    return back()->with('success', 'Status Changed.');
}  
}