//->get();
//dd($data);
    // foreach ($project as $value) {

    // 	# code...
    // }
    // $users = Project::select('project.*', 'issue.*', DB::raw('SUM(issue.status) As revenue'))
    //      ->Join('issue', 'issue.projectid', '=', 'project.id')
    //      ->where('issue.status', 'open')
    //      ->get();

    // $users = Project::leftJoin('issue', 'project.ID', '=', 'issue.projectid')
    //   ->selectRaw(DB::raw('SUM(issue.status) As revenue') where )
    //   ->groupBy('issue.projectid')
    //   ->get();
    //      dd($users);
         // select SUM(issue.status="CLOSED") as RoomsCount from `project` left join `issue` on `project`.`ID` = `issue`.`projectid` group by `issue`.`projectid`
//          $datap = \App\Project::join('issue', 'issue.projectid', '=', 'project.id')->where('issue.status','NEW')
// ->groupby('issue.projectid')
// ->selectRaw('SUM(issue.status="NEW") as RoomsCount')
// ->get(); 


// $users = DB::table('project')->join('issue', 'issue.projectid', '=', 'project.id')
//                      ->select('projects.*,'DB::raw('count(*) as user_count, issue.status'))
//                      ->where('issue.status', '<>', 'NEW')
//                      ->groupBy('issue.projectid')
//                      ->get();

// $data= \App\Issue::GroupBy('projectid')->orderBy('id','ASC')->leftjoin('project','project.id','=','issue.projectid')->select('project.*',DB::raw("COUNT(*) as count_row")); 
//                      dd($data);

// $projects = DB::table('project')
//             ->leftjoin('issue', 'project.id', '=', 'issue.projectid')
//             ->select('project.*','issue.*', DB::raw('sum(issue.status) as sum'))
//             ->DISTICT('issue.projectid')
//             ->get();
//             dd($projects);

  // $datap = DB::table('issue')
  //        ->leftjoin('project', 'project.id', '=', 'issue.projectid')
  //        ->select('project.id', DB::raw('COUNT(*) AS total'))
  //        ->where('issue.status',"NEW")
  //        ->groupBy('project.id')
  //        ->get();

  //        dd($datap);

// $datap = DB::table("`project`")
// ->leftJoin("`issue`", function($join){
// 	$join->on("`project`.`id`", "=", "`issue`.`projectid`");
// })
// ->select("sum (issue.status = 'new') as roomscount")
// ->get();

//dd($datap);
//dd($datap);

    // $project = \App\Project::orderby('id','DESC');
     // $project = Project::select('project.id', 'project.name', 'project.description', 'issue.tracker', 'issue.description', DB::raw('SUM(issue.status="NEW") As revenue'))
     // ->Join('issue', 'project.id', '=', 'issue.projectid')
     // //->where('issue.status', 'NEW')
     // ->groupBy('project.id', 'project.name', 'project.description', 'issue.tracker', 'issue.description') 
     // ->get();
     // dd($users);