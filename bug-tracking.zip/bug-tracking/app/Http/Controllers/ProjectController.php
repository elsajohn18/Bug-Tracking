<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Session;
use App\Project;
use App\Issue;
use Hash;
use DB;

class ProjectController extends Controller
{
	public function index(Request $request){
    $keyword = $request->input('name');

    $project = \App\Project::leftjoin('issue','project.ID','=','issue.projectid')
->groupby('project.id','project.name','project.description','project.status','project.created_at','project.updated_at' )->select('project.*')
->selectRaw('SUM(issue.status="NEW") as OpenCount');

    if($keyword != '' || $keyword != null)
  	{
    $project=$project->where('project.name','LIKE','%'.$keyword.'%');
    $project=$project->orwhere('project.description','LIKE','%'.$keyword.'%');
    }
    $project =$project->paginate(30);
    return view('project',['page'=>'project','project'=>$project,'keyword'=>$keyword]);
		}
    public function create()
    {	$page = 'project';
    	$project_details = '';
        return view('add_project',['page'=>$page,'project_details'=>$project_details]);
    }
public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required|alpha_num',
        ]);
           if ($validator->fails()) {
            return redirect('/project/create')
                        ->withErrors($validator)
                        ->withInput();
        }
        else
        {
        	$storeData=$request->all();
        	$storeData['status'] = 'open';
        	$Project=Project::create($storeData);
        }

        return back()->with('success', 'Project added successfully.');
    }
     public function edit($id)
    {
        $page = 'project';
        $project_details = Project::findorfail($id);
		return view('add_project',compact('page','project_details'));
    }
    public function update(Request $request,$id){
    	$validator = Validator::make($request->all(), [
'name' => 'required',
'description'=>'required',


]);
if ($validator->fails()) {

return redirect('project/'.$id.'/edit')
->withErrors($validator)
->withInput();
}
else
{
	$updateData=$request->all();
	$project = Project::find($id)->update($updateData);
}return back()->with('success','Updated Successfully!');
         }
      public function viewissues(Request $request,$id)
    
    {
        $page = 'issues';
        $keyword = $request->input('name');
        $tracker = $request->input('tracker');
        $status = $request->input('status');
         $dataproject = \App\Issue::leftJoin('project','project.id','=','issue.projectid')->where('projectid', $id)->select('project.id as pid','project.name as pname','project.description as pdesc')->first();
       $data = \App\Issue::leftJoin('project','project.id','=','issue.projectid')->where('projectid', $id)->select('project.id as pid','project.name as pname','project.description as pdesc','issue.*');
       if($keyword != '' || $keyword != null)
  	{
    $data=$data->where('project.name','LIKE','%'.$keyword.'%');
    $data=$data->orwhere('issue.description','LIKE','%'.$keyword.'%');
    }
    if($tracker != '' && $tracker!= null && $tracker!= 'All')
$data=$data->where('issue.tracker','=',$tracker);
if($status != '' && $status!= null && $status!= 'All')
$data=$data->where('issue.status','=',$status);
$data = $data->get();
        return view('viewissues',compact('page','data','keyword','tracker','status','dataproject'));
    }
          public function singleissue($id)
    {
        $page = 'issues';
       $data = \App\Issue::where('id', $id)->first();
        return view('singleissue',compact('page','data'));
    }
     
}